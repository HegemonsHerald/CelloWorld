#!/bin/sh
gcc -o TicTacToeServer TicTacToeServer.c TicTacToeFunctions.c -g
gcc -o TicTacToeClient TicTacToeClient.c -g
