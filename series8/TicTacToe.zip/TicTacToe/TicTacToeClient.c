#include <stdbool.h>     // use booleans in C
#include <stdlib.h>      // use common functions
#include <stdio.h>       // use input/output functions
#include <string.h>      // use string functions
#include <unistd.h>      // use POSIX functions

#include <sys/socket.h>  // use socket function
#include <netinet/in.h>  // use internet address datatypes
#include <arpa/inet.h>   // use inet_ntoa function
#include <netdb.h>       // use network database functions

/** Print field represented by given character array.
	The array must contains 9 chars ('O', 'X' or ' ')
	ordered row-wise from top left to bottom right. */
void printField(char* field)
{
	printf("+---+---+---+\n");
	for (int row = 0; row < 3; row++) {
		for (int col = 0; col < 3; col++) {
			printf("| %c ", field[row*3+col]);
		}
		printf("|\n+---+---+---+\n");
	}
}

/** Simple client application for Tic-Tac-Toe game using UDP.
    Hostname and port number of server are passed as arguments.
    By default, the server is assumed at localhost, port 5001.
*/
int main(int argc, char* argv[])
{
	// Read parameters
	if (argc != 3) {
		printf("Usage: TicTacToeClient [<hostname>] [<port>]\n\n");
	}
	char* hostname = argc > 1 ? argv[1] : "localhost";
	int port = argc > 2 ? atoi(argv[2]) : 5001;

	/** -- Setup connection -- */

	// TODO : Setup UDP/IP socket to communicate with server

	/** -- Main game -- */

	bool running = true;
	char message[16];
	char command[6];
	char field[9];
	memset(field, ' ', 9);
	printField(field);
	while (running)
	{
		// Read row and column from user
		int row = 0, col = 0;
		printf("Select row and column (1-3): ");
		scanf("%d %d", &row, &col);
		while (getchar() != '\n') {}  // discard remaining input
		if (row < 1 || row > 3 || col < 1 || col > 3) {
			printf("Invalid row or column!\n");
			continue;
		}

		// Update field
		int idx = (row-1)*3 + col-1;
		if (field[idx] != ' ') {
			printf("This field is already occupied!\n");
			continue;
		}
		field[idx] = 'X';
		printField(field);

		// TODO : Send message to server, receive and process response
	}

	return 0;
}
